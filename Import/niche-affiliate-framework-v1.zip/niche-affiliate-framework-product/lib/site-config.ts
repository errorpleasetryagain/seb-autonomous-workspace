// ─────────────────────────────────────────────────────────────────────────────
// SITE CONFIG — the only file you need to edit to customise this framework
// Change these values for your niche. Everything else updates automatically.
// ─────────────────────────────────────────────────────────────────────────────

export const siteConfig = {
  // Your site name — appears in header, OG tags, JSON-LD
  name: "Your Site Name",

  // Your production URL — used for canonical URLs, sitemap, OG
  url: "https://yourdomain.com",

  // Your domain (without https://)
  domain: "yourdomain.com",

  // Twitter/X handle (optional)
  handle: "@yourhandle",

  // Short tagline — appears in hero section
  tagline: "Your one-line value proposition here.",

  // Meta description — appears in Google search results (150-160 chars ideal)
  description: "Write your meta description here. This appears under your site name in Google search results. Make it compelling and include your main keyword.",

  // Your audience — used internally for content targeting
  audience: "Describe your target audience here",

  // Contact email
  email: "hello@yourdomain.com",

  // Author name — appears in article bylines and JSON-LD
  founder: "Your Name",
} as const;

export type SiteConfig = typeof siteConfig;
