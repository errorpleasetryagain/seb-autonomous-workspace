import { Metadata } from "next";
import { notFound } from "next/navigation";
import { getList, getAllListSlugs } from "@/lib/content";
import { AffiliateCard } from "@/components/ui/AffiliateCard";
import { EmailCapture } from "@/components/ui/EmailCapture";
import { siteConfig } from "@/lib/site-config";

export async function generateStaticParams() {
  return getAllListSlugs().map((slug) => ({ slug }));
}

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const list = await getList(params.slug);
  if (!list) return {};

  return {
    title: `${list.title} | ${siteConfig.name}`,
    description: list.intro,
  };
}

export default async function ListPage({
  params,
}: {
  params: { slug: string };
}) {
  const list = await getList(params.slug);
  if (!list) notFound();

  const { title, intro, pillar, products, updatedAt } = list;

  return (
    <>
      {/* Header */}
      <div className="pt-32 pb-12 max-w-4xl mx-auto px-4 sm:px-6">
        <span className="label-mono text-signal mb-4 block">{pillar}</span>
        <h1 className="heading-xl mb-4 text-balance">{title}</h1>
        <div className="divider-accent w-16 mb-6" />
        <p className="body-lg max-w-2xl">{intro}</p>
        <p className="font-mono text-xs text-muted mt-4">Last updated: {updatedAt}</p>
      </div>

      {/* Disclaimer */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 mb-8">
        <div className="border border-border/50 rounded-sm p-4 bg-surface/30">
          <p className="text-xs text-muted">{siteConfig.affiliateDisclaimer}</p>
        </div>
      </div>

      {/* Product cards */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 pb-24">
        <div className="flex flex-col gap-6">
          {products.map((product, i) => (
            <AffiliateCard
              key={product.name}
              product={product}
              featured={i === 0}
            />
          ))}
        </div>
      </div>

      <EmailCapture />
    </>
  );
}
