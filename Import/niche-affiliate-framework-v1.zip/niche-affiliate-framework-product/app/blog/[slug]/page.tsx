import { Metadata } from "next";
import { notFound } from "next/navigation";
import { siteConfig } from "@/lib/site-config";
import { formatDate } from "@/lib/utils";
import { getArticle, getAllArticleSlugs } from "@/lib/content";
import { EmailCapture } from "@/components/ui/EmailCapture";

export async function generateStaticParams() {
  return getAllArticleSlugs().map((slug) => ({ slug }));
}

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const article = await getArticle(params.slug);
  if (!article) return {};

  return {
    title: `${article.title} | ${siteConfig.name}`,
    description: article.excerpt,
    openGraph: {
      title: article.title,
      description: article.excerpt,
      type: "article",
      publishedTime: article.date,
    },
  };
}

export default async function ArticlePage({
  params,
}: {
  params: { slug: string };
}) {
  const article = await getArticle(params.slug);
  if (!article) notFound();

  const { title, date, pillar, readTime, content } = article;

  return (
    <>
      {/* Article header */}
      <div className="pt-32 pb-16 max-w-3xl mx-auto px-4 sm:px-6">
        <div className="mb-6">
          <span className="label-mono text-signal">{pillar}</span>
        </div>
        <h1 className="heading-xl mb-6 text-balance">{title}</h1>
        <div className="divider-accent w-16 mb-6" />
        <div className="flex items-center gap-4 text-xs text-muted font-mono">
          <span>{formatDate(date)}</span>
          {readTime && <span>·</span>}
          {readTime && <span>{readTime}</span>}
        </div>
      </div>

      {/* Affiliate disclaimer */}
      <div className="max-w-3xl mx-auto px-4 sm:px-6 mb-8">
        <div className="border border-border/50 rounded-sm p-4 bg-surface/30">
          <p className="text-xs text-muted">{siteConfig.affiliateDisclaimer}</p>
        </div>
      </div>

      {/* Article body */}
      <article className="max-w-3xl mx-auto px-4 sm:px-6 pb-24">
        <div className="prose-glwc">{content}</div>
      </article>

      {/* Email capture at end of every article */}
      <EmailCapture />
    </>
  );
}
