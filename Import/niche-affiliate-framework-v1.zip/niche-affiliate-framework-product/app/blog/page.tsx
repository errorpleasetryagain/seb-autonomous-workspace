import { Metadata } from "next";
import Link from "next/link";
import { getAllArticles } from "@/lib/content";
import { siteConfig } from "@/lib/site-config";
import { formatDate } from "@/lib/utils";

export const metadata: Metadata = {
  title: `Blog | ${siteConfig.name}`,
  description: `Evidence-based articles on testosterone, hormones, and male health optimisation. UK-focused, no bro science.`,
};

const PILLAR_COLOURS: Record<string, string> = {
  Foundations: "text-signal",
  Supplementation: "text-emerald-400",
  "TRT & Clinical": "text-blue-400",
  "Peptides & Advanced": "text-purple-400",
  "Lifestyle Protocols": "text-amber-400",
};

export default async function BlogPage() {
  const articles = await getAllArticles();

  const featured = articles.find((a) => a.featured) ?? articles[0];
  const rest = articles.filter((a) => a.slug !== featured?.slug);

  return (
    <div className="pt-32 pb-24 max-w-5xl mx-auto px-4 sm:px-6">
      {/* Page header */}
      <p className="label-mono mb-4">Articles</p>
      <h1 className="heading-xl mb-4">The Blog</h1>
      <div className="divider-accent w-16 mb-12" />

      {/* Featured article */}
      {featured && (
        <Link
          href={`/blog/${featured.slug}`}
          className="block card hover:border-signal/40 transition-colors mb-16 group"
        >
          <span
            className={`label-mono mb-3 block ${PILLAR_COLOURS[featured.pillar] ?? "text-signal"}`}
          >
            {featured.pillar}
          </span>
          <h2 className="heading-lg mb-3 group-hover:text-signal transition-colors">
            {featured.title}
          </h2>
          <p className="text-offwhite/60 text-sm mb-4 leading-relaxed">
            {featured.excerpt}
          </p>
          <div className="flex items-center gap-3 text-xs font-mono text-muted">
            <span>{formatDate(featured.date)}</span>
            {featured.readTime && (
              <>
                <span>·</span>
                <span>{featured.readTime}</span>
              </>
            )}
            <span className="ml-auto text-signal group-hover:translate-x-1 transition-transform">
              Read →
            </span>
          </div>
        </Link>
      )}

      {/* Article grid */}
      {rest.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {rest.map((article) => (
            <Link
              key={article.slug}
              href={`/blog/${article.slug}`}
              className="block card hover:border-signal/40 transition-colors group"
            >
              <span
                className={`label-mono mb-3 block text-xs ${PILLAR_COLOURS[article.pillar] ?? "text-signal"}`}
              >
                {article.pillar}
              </span>
              <h2 className="heading-lg text-lg mb-2 group-hover:text-signal transition-colors leading-snug">
                {article.title}
              </h2>
              <p className="text-offwhite/50 text-sm mb-4 leading-relaxed line-clamp-3">
                {article.excerpt}
              </p>
              <div className="flex items-center gap-3 text-xs font-mono text-muted">
                <span>{formatDate(article.date)}</span>
                {article.readTime && (
                  <>
                    <span>·</span>
                    <span>{article.readTime}</span>
                  </>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}

      {articles.length === 0 && (
        <p className="text-offwhite/40 text-sm font-mono">
          No articles yet — content coming soon.
        </p>
      )}
    </div>
  );
}
