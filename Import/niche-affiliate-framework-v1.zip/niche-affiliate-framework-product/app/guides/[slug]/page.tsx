import { Metadata } from "next";
import { notFound } from "next/navigation";
import { getGuide, getAllGuideSlugs } from "@/lib/content";
import { EmailCapture } from "@/components/ui/EmailCapture";
import { siteConfig } from "@/lib/site-config";

export async function generateStaticParams() {
  return getAllGuideSlugs().map((slug) => ({ slug }));
}

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const guide = await getGuide(params.slug);
  if (!guide) return {};

  const description = guide.excerpt || guide.intro;
  const url = `${siteConfig.url}/guides/${guide.slug}`;

  return {
    title: guide.title,
    description,
    alternates: {
      canonical: url,
    },
    openGraph: {
      title: guide.title,
      description,
      url,
      type: "article",
      publishedTime: guide.date,
      modifiedTime: guide.updatedAt,
      authors: guide.author ? [`${siteConfig.url}/about`] : undefined,
      siteName: siteConfig.name,
      locale: "en_GB",
    },
    twitter: {
      card: "summary_large_image",
      title: guide.title,
      description,
      creator: siteConfig.handle,
    },
  };
}

export default async function GuidePage({
  params,
}: {
  params: { slug: string };
}) {
  const guide = await getGuide(params.slug);
  if (!guide) notFound();

  const { title, intro, pillar, sections, updatedAt, content } = guide;
  const description = guide.excerpt || intro;
  const canonicalUrl = `${siteConfig.url}/guides/${guide.slug}`;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: title,
    description,
    url: canonicalUrl,
    datePublished: guide.date,
    dateModified: updatedAt,
    author: {
      "@type": "Person",
      name: guide.author ?? "Seb",
      url: `${siteConfig.url}/about`,
    },
    publisher: {
      "@type": "Organization",
      name: siteConfig.name,
      url: siteConfig.url,
    },
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": canonicalUrl,
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      {/* Header */}
      <div className="pt-32 pb-12 max-w-3xl mx-auto px-4 sm:px-6">
        <span className="label-mono text-signal mb-4 block">{pillar}</span>
        <h1 className="heading-xl mb-4 text-balance">{title}</h1>
        <div className="divider-accent w-16 mb-6" />
        <p className="body-lg">{intro}</p>
        <p className="font-mono text-xs text-muted mt-4">Last updated: {updatedAt}</p>
      </div>

      {/* Table of contents */}
      {sections && sections.length > 0 && (
        <div className="max-w-3xl mx-auto px-4 sm:px-6 mb-10">
          <div className="card">
            <p className="label-mono mb-4">In this guide</p>
            <ol className="flex flex-col gap-2">
              {sections.map((s, i) => (
                <li key={s} className="flex items-center gap-3 text-sm text-offwhite/70">
                  <span className="font-mono text-signal/60 text-xs">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <a
                    href={`#${s.toLowerCase().replace(/\s+/g, "-")}`}
                    className="hover:text-signal transition-colors"
                  >
                    {s}
                  </a>
                </li>
              ))}
            </ol>
          </div>
        </div>
      )}

      {/* Disclaimer */}
      <div className="max-w-3xl mx-auto px-4 sm:px-6 mb-8">
        <div className="border border-border/50 rounded-sm p-4 bg-surface/30">
          <p className="text-xs text-muted">{siteConfig.affiliateDisclaimer}</p>
        </div>
      </div>

      {/* Guide content */}
      <article className="max-w-3xl mx-auto px-4 sm:px-6 pb-24">
        <div className="prose-glwc">{content}</div>
      </article>

      <EmailCapture />
    </>
  );
}
