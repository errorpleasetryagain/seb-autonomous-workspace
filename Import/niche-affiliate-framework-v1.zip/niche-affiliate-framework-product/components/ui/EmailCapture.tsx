"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { siteConfig } from "@/lib/site-config";

export function EmailCapture() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setStatus("loading");

    // TODO: replace with your email provider (Mailchimp / ConvertKit / Resend)
    try {
      const res = await fetch(siteConfig.leadMagnet.formAction, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email_address: email }),
      });
      setStatus(res.ok ? "success" : "error");
    } catch {
      setStatus("error");
    }
  };

  return (
    <section id="newsletter" className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-surface/50" />
      <div className="absolute inset-0 bg-gradient-to-r from-signal/5 to-transparent" />

      <div className="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <p className="label-mono mb-4">Free resource</p>
          <h2 className="heading-xl mb-4">{siteConfig.leadMagnet.title}</h2>
          <div className="divider-accent w-24 mx-auto my-6" />
          <p className="body-lg mb-10">{siteConfig.leadMagnet.description}</p>

          {status === "success" ? (
            <div className="card max-w-md mx-auto border-signal/40">
              <p className="label-mono text-signal mb-2">Done.</p>
              <p className="text-offwhite/80">Check your inbox — it&apos;s on its way.</p>
            </div>
          ) : (
            <form
              onSubmit={handleSubmit}
              className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
            >
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                required
                className="flex-1 bg-void border border-border text-offwhite placeholder:text-muted
                           px-4 py-3 rounded-sm font-body text-sm
                           focus:outline-none focus:border-signal transition-colors"
              />
              <button
                type="submit"
                disabled={status === "loading"}
                className="btn-primary whitespace-nowrap"
              >
                {status === "loading" ? "Sending…" : siteConfig.leadMagnet.ctaLabel}
              </button>
            </form>
          )}

          {status === "error" && (
            <p className="mt-3 text-sm text-signal/80">Something went wrong. Try again.</p>
          )}

          <p className="mt-4 text-xs text-muted">No spam. Unsubscribe any time.</p>
        </motion.div>
      </div>
    </section>
  );
}
